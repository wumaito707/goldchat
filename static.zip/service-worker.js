// Only the offline notice is cached. Private messages, API responses and media are never cached.
const CACHE='goldchat-offline-v1';
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.add('/static/offline.html'))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('goldchat-offline-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method==='GET'&&event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).catch(()=>caches.match('/static/offline.html')));
  }
});

self.addEventListener('push',event=>{
  let data={title:'GOLDCHAT',body:'You have a new message.'};
  try{if(event.data)data={...data,...event.data.json()};}catch(e){}
  event.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/static/icons/icon-192.png',badge:'/static/icons/icon-192.png',tag:'goldchat-chat-'+(data.chat_id||'new'),data:{url:'/?chat='+encodeURIComponent(data.chat_id||'')},vibrate:[150,75,150]}));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();const url=new URL(event.notification.data?.url||'/',self.location.origin).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(async windows=>{
    const existing=windows.find(client=>new URL(client.url).origin===self.location.origin);
    if(existing){await existing.navigate(url);return existing.focus();}
    return self.clients.openWindow(url);
  }));
});
